# mypackage
this liberary created as an example of how publish a package

# How to install
...
