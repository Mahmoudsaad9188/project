
from . import myModule
